### This directory contains images used in [pedagogy document](https://github.com/virtual-labs/ph3-exp-dev-process/blob/main/pedagogy/README.org).
