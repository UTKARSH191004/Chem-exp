A.	Mahramanlıoğlu, M. and Tuncay, M., 2011. The distribution coefficients of acetic acid between water and solvent systems. Pamukkale Üniversitesi Mühendislik Bilimleri Dergisi, 7(3)<br>

B.	Van Haelst, A.G., Heesen, P.F., Van Der Wielen, F.W.M. and Govers, H.A.J., 1994. Determination of n-octanol/water partition coefficients of tetrachlorobenzyltoluenes individually and in a mixture by the slow stirring method. Chemosphere, 29(8), pp.1651-1660<br>

C.	Sangster, J.M., 1997. Octanol-water partition coefficients: fundamentals and physical chemistry (Vol. 1). John Wiley & Sons
















