##  Partition coefficient of acetic acid in water and butanol 
