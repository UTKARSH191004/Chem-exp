<b> Materials & Reagents Required</b><br>
A.	Separating funnel (500 mL)<br>
B.	Volumetric flask (250 mL)<br>
C.	Measuring Cylinder (100mL)<br>
D.	Burette (25 mL)<br>
E.	Pipette (1mL & 5mL)<br>
F.	Conical flask (250 mL)<br><br>
<b> Procedure in laboratory diagram</b><br>
<img src="images/image2.png"><br>
<img src="images/image3.png"><br>
<img src="images/image4.png"><br>
<img src="images/image5.png"><br><br>
<b>Procedure in laboratory</b><br>
<img src="images/image6.png"><br><br>
<b>Sample Data and Analysis</b><br>
Standardization of NaOH solutio<br>
Strength of Oxalic acid = 0.1 M (or 0.2 N)<br>
Indicator used = Phenolphthalein<br>
End point  = Colorless to pink<br>

<img src="images/image7.png"><br>
<b>Calculation:</b><br>
Number of equivalents of NaOH = Number of equivalents of oxalic acid.<br>
<img src="images/image8.png"><br>
<img src="images/image9.png">

























