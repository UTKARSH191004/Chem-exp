## Introduction


<b>Discipline | <b> Chemical Engineering
:--|:--|
<b> Lab | <b> Basic Chemistry Laboratory-I
<b> Experiment| <b> Partition coefficient of acetic acid in water and butanol

### About the Experiment 

To determine partition coefficient of acetic acid in water and butanol.

<b>Name of Developer | <b> Prof. Pratik Sen 
:--|:--|
<b> Institute | <b>  Indian Institute of Technology Kanpur
<b> Email id|     <b>  psen@iitk.ac.in
<b> Department |  Department of Chemistry

### Contributors List

SrNo | Name | Faculty or Student | Department| Institute | Email id
:--|:--|:--|:--|:--|:--|
1 | Akash Latya | Student | Computer Science & Information Technology | BU Jhansi | akashlatya000@gmail.com
